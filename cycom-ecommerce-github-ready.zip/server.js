require("dotenv").config();

const express = require("express");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const multer = require("multer");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-this";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-me";
const SHOP_NAME = process.env.SHOP_NAME || "Cycom E-Commerce";
const WHATSAPP = process.env.WHATSAPP || "221776056015";

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const UPLOADS = path.join(ROOT, "uploads");
fs.mkdirSync(UPLOADS, { recursive: true });

const db = new Database(path.join(ROOT, "cycom.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  price INTEGER NOT NULL DEFAULT 0,
  category TEXT DEFAULT 'Autres',
  image TEXT DEFAULT '',
  stock INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT DEFAULT '',
  customer_phone TEXT DEFAULT '',
  customer_address TEXT DEFAULT '',
  items_json TEXT NOT NULL,
  total INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Nouvelle',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOADS),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const safe = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
      cb(null, safe);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = ["image/jpeg", "image/png", "image/webp", "image/gif"].includes(file.mimetype);
    cb(ok ? null : new Error("Format image non autorisé"), ok);
  }
});

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use("/uploads", express.static(UPLOADS));

function auth(req, res, next) {
  const token = req.cookies.cycom_token;
  if (!token) return res.status(401).json({ error: "Non authentifié" });
  try {
    req.admin = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.clearCookie("cycom_token");
    return res.status(401).json({ error: "Session expirée" });
  }
}

function cleanProduct(body) {
  return {
    name: String(body.name || "").trim(),
    description: String(body.description || "").trim(),
    price: Math.max(0, Number(body.price || 0)),
    category: String(body.category || "Autres").trim(),
    image: String(body.image || "").trim(),
    stock: Math.max(0, Number(body.stock || 0))
  };
}

app.get("/api/config", (_req, res) => {
  res.json({ shopName: SHOP_NAME, whatsapp: WHATSAPP });
});

app.post("/api/admin/login", async (req, res) => {
  const password = String(req.body.password || "");
  const valid = ADMIN_PASSWORD.startsWith("$2")
    ? await bcrypt.compare(password, ADMIN_PASSWORD)
    : password === ADMIN_PASSWORD;

  if (!valid) return res.status(401).json({ error: "Mot de passe incorrect" });

  const token = jwt.sign({ role: "admin" }, JWT_SECRET, { expiresIn: "7d" });
  res.cookie("cycom_token", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  });
  res.json({ ok: true });
});

app.post("/api/admin/logout", (_req, res) => {
  res.clearCookie("cycom_token");
  res.json({ ok: true });
});

app.get("/api/admin/me", auth, (_req, res) => {
  res.json({ authenticated: true, role: "admin" });
});

app.get("/api/products", (_req, res) => {
  const products = db.prepare("SELECT * FROM products ORDER BY id DESC").all();
  res.json(products);
});

app.get("/api/products/:id", (req, res) => {
  const product = db.prepare("SELECT * FROM products WHERE id = ?").get(req.params.id);
  if (!product) return res.status(404).json({ error: "Produit introuvable" });
  res.json(product);
});

app.post("/api/products", auth, (req, res) => {
  const p = cleanProduct(req.body);
  if (!p.name) return res.status(400).json({ error: "Le nom du produit est obligatoire" });

  const result = db.prepare(`
    INSERT INTO products (name, description, price, category, image, stock)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(p.name, p.description, p.price, p.category, p.image, p.stock);

  res.status(201).json(db.prepare("SELECT * FROM products WHERE id = ?").get(result.lastInsertRowid));
});

app.put("/api/products/:id", auth, (req, res) => {
  const p = cleanProduct(req.body);
  if (!p.name) return res.status(400).json({ error: "Le nom du produit est obligatoire" });

  const result = db.prepare(`
    UPDATE products
    SET name=?, description=?, price=?, category=?, image=?, stock=?, updated_at=CURRENT_TIMESTAMP
    WHERE id=?
  `).run(p.name, p.description, p.price, p.category, p.image, p.stock, req.params.id);

  if (!result.changes) return res.status(404).json({ error: "Produit introuvable" });
  res.json(db.prepare("SELECT * FROM products WHERE id = ?").get(req.params.id));
});

app.delete("/api/products/:id", auth, (req, res) => {
  const result = db.prepare("DELETE FROM products WHERE id = ?").run(req.params.id);
  if (!result.changes) return res.status(404).json({ error: "Produit introuvable" });
  res.json({ ok: true });
});

app.post("/api/upload", auth, upload.single("image"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Aucune image reçue" });
  res.json({ url: `/uploads/${req.file.filename}` });
});

app.post("/api/orders", (req, res) => {
  const { customer_name = "", customer_phone = "", customer_address = "", items = [], total = 0 } = req.body;
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Commande vide" });
  }

  const result = db.prepare(`
    INSERT INTO orders (customer_name, customer_phone, customer_address, items_json, total)
    VALUES (?, ?, ?, ?, ?)
  `).run(
    String(customer_name),
    String(customer_phone),
    String(customer_address),
    JSON.stringify(items),
    Math.max(0, Number(total || 0))
  );

  res.status(201).json({
    id: result.lastInsertRowid,
    whatsapp: WHATSAPP,
    message: "Commande enregistrée"
  });
});

app.get("/api/orders", auth, (_req, res) => {
  const orders = db.prepare("SELECT * FROM orders ORDER BY id DESC").all()
    .map(o => ({ ...o, items: JSON.parse(o.items_json) }));
  res.json(orders);
});

app.patch("/api/orders/:id/status", auth, (req, res) => {
  const status = String(req.body.status || "Nouvelle");
  const allowed = ["Nouvelle", "Confirmée", "Expédiée", "Livrée", "Annulée"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Statut invalide" });

  const result = db.prepare("UPDATE orders SET status=? WHERE id=?").run(status, req.params.id);
  if (!result.changes) return res.status(404).json({ error: "Commande introuvable" });
  res.json(db.prepare("SELECT * FROM orders WHERE id=?").get(req.params.id));
});

app.get("/api/admin/stats", auth, (_req, res) => {
  const products = db.prepare("SELECT COUNT(*) AS n FROM products").get().n;
  const orders = db.prepare("SELECT COUNT(*) AS n FROM orders").get().n;
  const sales = db.prepare("SELECT COALESCE(SUM(total),0) AS total FROM orders WHERE status != 'Annulée'").get().total;
  res.json({ products, orders, sales });
});

app.use(express.static(PUBLIC));

app.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || "Erreur serveur" });
});

app.listen(PORT, () => {
  console.log(`${SHOP_NAME} : http://localhost:${PORT}`);
});