# Cycom E-Commerce — Backend

## 1. Installer Node.js
Installe Node.js 20 LTS ou une version récente.

## 2. Installer les dépendances
Dans ce dossier :
```bash
npm install
```

## 3. Configurer
Copie `.env.example` vers `.env`, puis change au minimum :
- `JWT_SECRET`
- `ADMIN_PASSWORD`

Le numéro WhatsApp est déjà configuré sur `221776056015`.

## 4. Démarrer
```bash
npm start
```

Puis ouvre :
- Boutique : http://localhost:3000
- Administration : http://localhost:3000/admin.html

## 5. Administration
Le mot de passe est celui défini dans `.env`.

Tu peux :
- ajouter des produits
- modifier les prix
- modifier les descriptions
- modifier le stock
- importer des images
- supprimer des produits
- voir les commandes
- changer le statut des commandes

## Important
Pour que le site soit accessible à tout le monde avec un vrai lien Internet, il faut déployer ce projet sur un hébergeur compatible Node.js et utiliser une base de données persistante. SQLite convient très bien pour tester/localement ; pour une plateforme de production qui scale, PostgreSQL est généralement préférable.


## Structure

- `public/index.html` = boutique publique
- `public/admin.html` = panneau d'administration
- `server.js` = backend/API
- `uploads/` = images importées
- `cycom.db` = base SQLite créée automatiquement

## GitHub

Le projet est prêt à être envoyé dans un dépôt GitHub.
Après connexion de GitHub, le dépôt peut être créé et les fichiers publiés.

## Sécurité

Ne publie jamais `.env`, un vrai mot de passe administrateur ou des secrets JWT dans GitHub.
